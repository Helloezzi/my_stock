# ui/scanner_view.py
import streamlit as st


def render_scanner_results(scan_df, name_map, state_key="selected_scan_ticker"):
    if scan_df is None or scan_df.empty:
        st.warning("No scan results.")
        return None

    st.subheader("Scanner Results")

    display_df = scan_df.copy()

    # 보기용 name 컬럼
    display_df["name"] = display_df["ticker"].map(
        lambda x: name_map.get(x, x)
    )

    st.dataframe(
        display_df,
        use_container_width=True,
        hide_index=True,
    )

    tickers = display_df["ticker"].tolist()

    if not tickers:
        return None

    current = st.session_state.get(state_key, tickers[0])
    if current not in tickers:
        current = tickers[0]
        st.session_state[state_key] = current

    pick = st.selectbox(
        "Pick from results to view chart",
        options=tickers,
        index=tickers.index(current),
        format_func=lambda x: f"{x} - {name_map.get(x, x)}",
        key=f"{state_key}_selectbox",
    )

    st.session_state[state_key] = pick
    return pick